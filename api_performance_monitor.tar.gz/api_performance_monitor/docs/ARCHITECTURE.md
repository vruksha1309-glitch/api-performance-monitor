# System Architecture & Design Diagrams
# API Performance Monitor

---

## 1. System Architecture (Text Diagram)

```
╔══════════════════════════════════════════════════════════════════════╗
║                        PRESENTATION LAYER                            ║
║  ┌───────────────────────────────────────────────────────────────┐   ║
║  │  Web Browser (Admin Dashboard)                                │   ║
║  │  • Chart.js visualizations    • Fetch API polling             │   ║
║  │  • Responsive HTML/CSS/JS     • Real-time alert badge         │   ║
║  └───────────────────────────────┬───────────────────────────────┘   ║
╚══════════════════════════════════╪═══════════════════════════════════╝
                                   │ HTTP/HTTPS
╔══════════════════════════════════╪═══════════════════════════════════╗
║                         APPLICATION LAYER                            ║
║  ┌─────────────┐ ┌──────────────┴─┐ ┌────────────┐ ┌────────────┐  ║
║  │ Auth BP     │ │  Dashboard BP   │ │Monitor BP  │ │ Reports BP │  ║
║  │ /auth/*     │ │  / + /api/*     │ │/monitoring │ │ /reports   │  ║
║  └─────────────┘ └────────────────┘ └────────────┘ └────────────┘  ║
║  ┌─────────────────────────────────────────────────────────────────┐ ║
║  │                     APScheduler (Daemon Thread)                 │ ║
║  │   • Reads active APIs from DB every 30 s                        │ ║
║  │   • Dispatches per-API jobs at configured intervals             │ ║
║  │   • Writes results to monitoring_logs                           │ ║
║  └─────────────────────────────────────────────────────────────────┘ ║
╚══════════════════════════════════╪═══════════════════════════════════╝
                                   │ sqlite3
╔══════════════════════════════════╪═══════════════════════════════════╗
║                           DATA LAYER                                  ║
║  ┌───────────────────────────────▼───────────────────────────────┐   ║
║  │                      SQLite Database                          │   ║
║  │  users  │  apis  │  monitoring_logs  │  reports               │   ║
║  └───────────────────────────────────────────────────────────────┘   ║
╚══════════════════════════════════════════════════════════════════════╝
                                   │ SQL queries (optional)
╔══════════════════════════════════╪═══════════════════════════════════╗
║                       VISUALIZATION LAYER                            ║
║  ┌──────────────────────────────────────────────────────────────┐    ║
║  │                   Grafana (port 3000)                        │    ║
║  │   frser-sqlite-datasource → dashboard panels                 │    ║
║  └──────────────────────────────────────────────────────────────┘    ║
╚══════════════════════════════════════════════════════════════════════╝
```

---

## 2. Data Flow Diagram (DFD) — Level 0 (Context)

```
                    ┌─────────────────┐
    login/          │                 │   schedule
    manage APIs ───►│   API           │◄── pings
    view dashboard  │   Performance   │
                    │   Monitor       │───► External APIs
    reports         │   System        │     (GET requests)
    ◄───────────────│                 │
                    └────────┬────────┘
                             │
                       store/retrieve
                             │
                    ┌────────▼────────┐
                    │  SQLite DB      │
                    └─────────────────┘
```

---

## 3. DFD Level 1

```
Admin ──[credentials]──► [1. Authenticate] ──[session]──► Admin (logged in)

Admin ──[API details]──► [2. Manage APIs] ──[CRUD]──► apis table

                         [3. Scheduler]  ──[GET]──► External APIs
                              │                          │
                              │◄────[response/error]─────┘
                              │
                              └──[log row]──► monitoring_logs table

Admin ──[dashboard req]──► [4. Analytics] ──[SQL aggregates]──► monitoring_logs
                                │
                                └──[JSON]──► Browser (Chart.js renders)

Admin ──[report params]──► [5. Reports] ──[SQL query]──► monitoring_logs
                                │
                                └──[PDF/CSV]──► Admin download

                         [6. Alert Engine] ──[read]──► monitoring_logs
                              │
                              └──[JSON alerts]──► Dashboard badge / Alerts page
```

---

## 4. Use Case Diagram (Description)

### Actors
- **Admin** — the single authenticated user
- **APScheduler** — the background monitoring agent
- **External API** — the third-party HTTP endpoints being monitored

### Use Cases

| ID  | Use Case               | Actor      | Description                                      |
|-----|------------------------|------------|--------------------------------------------------|
| UC1 | Login                  | Admin      | Authenticate with username + password            |
| UC2 | Logout                 | Admin      | Clear session                                    |
| UC3 | Change Password        | Admin      | Update hashed password in DB                     |
| UC4 | Add API                | Admin      | Register a new endpoint URL with interval        |
| UC5 | Edit API               | Admin      | Modify name, URL, interval, or status            |
| UC6 | Delete API             | Admin      | Remove API and cascade-delete logs               |
| UC7 | Toggle Monitoring      | Admin      | Enable / disable an API's monitoring             |
| UC8 | Manual Test            | Admin      | On-demand single ping, result shown immediately  |
| UC9 | View Logs              | Admin      | Browse last 100 results for a specific API       |
| UC10| View Dashboard         | Admin      | See stat cards + charts + recent activity        |
| UC11| View Alerts            | Admin      | See current downtime + slow-response alerts      |
| UC12| Export CSV             | Admin      | Download filtered log data as CSV                |
| UC13| Export PDF             | Admin      | Download performance summary as PDF              |
| UC14| Auto-Ping APIs         | APScheduler| GET requests at configured intervals             |
| UC15| Log Results            | APScheduler| INSERT response time, status, availability       |
| UC16| Respond to Ping        | External API| Return HTTP response (or timeout/error)         |

---

## 5. Sequence Diagram — Auto-Monitoring Flow

```
APScheduler        SQLite DB         External API
     │                  │                  │
     │  SELECT active    │                  │
     │  apis every 30s   │                  │
     │──────────────────►│                  │
     │◄──────────────────│                  │
     │  [list of APIs]   │                  │
     │                  │                  │
     │  For each API:    │                  │
     │  GET endpoint_url │                  │
     │───────────────────────────────────►  │
     │◄───────────────────────────────────  │
     │  HTTP response (or timeout)          │
     │                  │                  │
     │  INSERT log row  │                  │
     │  (rt, code, ok)  │                  │
     │──────────────────►│                  │
     │◄──────────────────│                  │
     │  (committed)      │                  │
```

---

## 6. Sequence Diagram — Admin Login & Dashboard

```
Browser          Flask (Auth BP)    SQLite DB
   │                   │                │
   │  GET /auth/login  │                │
   │──────────────────►│                │
   │◄──────────────────│                │
   │  login form HTML  │                │
   │                   │                │
   │  POST /auth/login │                │
   │  {user, password} │                │
   │──────────────────►│                │
   │                   │  SELECT users  │
   │                   │───────────────►│
   │                   │◄───────────────│
   │                   │  row / None    │
   │                   │                │
   │                   │  SHA-256 compare
   │                   │                │
   │◄──────────────────│                │
   │  302 → /          │                │
   │                   │                │
   │  GET /            │                │
   │──────────────────►│                │
   │◄──────────────────│                │
   │  dashboard HTML   │                │
   │                   │                │
   │  GET /api/stats   │                │
   │──────────────────►│                │
   │                   │  SELECT aggs   │
   │                   │───────────────►│
   │                   │◄───────────────│
   │◄──────────────────│                │
   │  JSON {stats}     │                │
   │  Chart.js renders │                │
```

---

## 7. Sample Screenshots Description

### Screen 1 — Login Page
Dark midnight background with a centred card. Gradient brand icon, username/password fields, "Sign In" button in crimson. Subtle radial glow behind the card.

### Screen 2 — Dashboard
Six stat cards across the top (Total APIs, Active, Avg RT, Total Requests, Failed, Uptime). Below: a 2-column chart grid — response-time line chart left, daily-bar chart right. Second row: doughnut availability chart left, live activity table right.

### Screen 3 — API Management
Full-width table with columns: ID, Name, URL, Interval, Status badge (green Active / grey Inactive), Created, Actions (pause/play, lightning test, logs, edit, delete).

### Screen 4 — Alerts Page
Active alerts rendered as colour-coded cards (red = down, yellow = slow / low uptime) with API name, message, and timestamp. Below: failure history table.

### Screen 5 — Reports Page
Two-column layout: left = filter form (API dropdown, date pickers, Export CSV / Export PDF buttons); right = per-API summary table with uptime badge colouring. Past-reports log at the bottom.

### Screen 6 — Grafana Dashboard
Response-time time series, error-rate gauge, uptime bar chart, request-volume histogram, and an API status table — all querying the same SQLite file.

---

## 8. Conclusion

The API Performance Monitor successfully delivers:
- **Real-time automated monitoring** via a non-blocking background scheduler
- **Actionable insights** through an interactive Chart.js dashboard
- **Proactive alerting** that surfaces downtime and degraded performance
- **Exportable reporting** in both CSV and PDF formats
- **Optional Grafana integration** for enterprise-grade time-series visualisation
- **Clean, extensible codebase** using Flask Blueprints and a clear layered architecture

The system is ready to run on any Python 3.11+ environment with a single `python run.py` command, making it an ideal final-year demonstration of full-stack web development, database design, background task scheduling, and data visualisation principles.
