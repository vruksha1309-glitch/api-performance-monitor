"""
Database Module
===============
Handles SQLite connection, schema creation, and query helpers.
"""

import sqlite3
import os
from flask import g, current_app


def get_db():
    """Return a database connection scoped to the current request."""
    if 'db' not in g:
        db_path = current_app.config['DATABASE_PATH']
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        g.db = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    """Close the database connection at end of request."""
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    """Create tables and seed admin user if not present."""
    from .config import Config
    db_path = Config.DATABASE_PATH
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    # ── Schema ────────────────────────────────────────────────────────────────
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT    NOT NULL UNIQUE,
            password    TEXT    NOT NULL,
            role        TEXT    NOT NULL DEFAULT 'admin',
            created_at  TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS apis (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            api_name            TEXT    NOT NULL,
            endpoint_url        TEXT    NOT NULL,
            monitoring_interval INTEGER NOT NULL DEFAULT 60,
            status              TEXT    NOT NULL DEFAULT 'active',
            created_at          TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS monitoring_logs (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            api_id        INTEGER NOT NULL REFERENCES apis(id) ON DELETE CASCADE,
            response_time REAL,
            status_code   INTEGER,
            availability  INTEGER NOT NULL DEFAULT 1,
            error_message TEXT,
            monitored_at  TEXT    DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS reports (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            report_name  TEXT NOT NULL,
            report_type  TEXT NOT NULL DEFAULT 'pdf',
            file_path    TEXT,
            generated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_logs_api_id   ON monitoring_logs(api_id);
        CREATE INDEX IF NOT EXISTS idx_logs_monitored ON monitoring_logs(monitored_at);
    """)

    # ── Seed admin user ────────────────────────────────────────────────────────
    existing = conn.execute("SELECT id FROM users WHERE username = 'admin'").fetchone()
    if not existing:
        import hashlib
        pw_hash = hashlib.sha256("admin123".encode()).hexdigest()
        conn.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            ("admin", pw_hash, "admin")
        )

    # ── Seed sample APIs ───────────────────────────────────────────────────────
    count = conn.execute("SELECT COUNT(*) FROM apis").fetchone()[0]
    if count == 0:
        sample_apis = [
            ("JSONPlaceholder Posts",  "https://jsonplaceholder.typicode.com/posts",   30,  "active"),
            ("JSONPlaceholder Users",  "https://jsonplaceholder.typicode.com/users",   60,  "active"),
            ("HTTPBin GET",            "https://httpbin.org/get",                       45,  "active"),
            ("HTTPBin Status 200",     "https://httpbin.org/status/200",               120, "active"),
            ("GitHub API",             "https://api.github.com",                        60,  "active"),
        ]
        conn.executemany(
            "INSERT INTO apis (api_name, endpoint_url, monitoring_interval, status) VALUES (?,?,?,?)",
            sample_apis
        )

    conn.commit()
    conn.close()
