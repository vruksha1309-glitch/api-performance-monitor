"""
Dashboard Blueprint
===================
Main analytics dashboard with aggregated statistics.
"""

from flask import Blueprint, render_template, jsonify
from ..auth.routes import login_required
from ..database import get_db

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/')
@login_required
def index():
    """Main dashboard page."""
    return render_template('dashboard/index.html')


@dashboard_bp.route('/api/stats')
@login_required
def api_stats():
    """JSON endpoint: summary statistics for the dashboard cards."""
    db = get_db()

    total_apis  = db.execute("SELECT COUNT(*) FROM apis").fetchone()[0]
    active_apis = db.execute("SELECT COUNT(*) FROM apis WHERE status = 'active'").fetchone()[0]
    total_reqs  = db.execute("SELECT COUNT(*) FROM monitoring_logs").fetchone()[0]
    failed_reqs = db.execute(
        "SELECT COUNT(*) FROM monitoring_logs WHERE availability = 0"
    ).fetchone()[0]

    avg_rt_row = db.execute(
        "SELECT AVG(response_time) FROM monitoring_logs WHERE response_time IS NOT NULL"
    ).fetchone()
    avg_rt = round(avg_rt_row[0] or 0, 2)

    uptime = 0.0
    if total_reqs > 0:
        uptime = round(((total_reqs - failed_reqs) / total_reqs) * 100, 2)

    return jsonify({
        'total_apis':    total_apis,
        'active_apis':   active_apis,
        'total_requests': total_reqs,
        'failed_requests': failed_reqs,
        'avg_response_time': avg_rt,
        'uptime_percentage': uptime,
    })


@dashboard_bp.route('/api/chart/response-time')
@login_required
def chart_response_time():
    """JSON: last 24 h average response time per hour, per API."""
    db = get_db()
    rows = db.execute("""
        SELECT
            a.api_name,
            strftime('%H:00', ml.monitored_at) AS hour,
            ROUND(AVG(ml.response_time), 2)    AS avg_rt
        FROM monitoring_logs ml
        JOIN apis a ON a.id = ml.api_id
        WHERE ml.monitored_at >= datetime('now', '-24 hours')
          AND ml.response_time IS NOT NULL
        GROUP BY a.api_name, hour
        ORDER BY hour
    """).fetchall()

    # Reshape into {api_name: [{hour, avg_rt}]}
    data = {}
    for r in rows:
        name = r['api_name']
        data.setdefault(name, []).append({'hour': r['hour'], 'avg_rt': r['avg_rt']})

    return jsonify(data)


@dashboard_bp.route('/api/chart/daily-stats')
@login_required
def chart_daily_stats():
    """JSON: daily total vs failed requests for the last 7 days."""
    db = get_db()
    rows = db.execute("""
        SELECT
            strftime('%Y-%m-%d', monitored_at) AS day,
            COUNT(*)                            AS total,
            SUM(CASE WHEN availability = 0 THEN 1 ELSE 0 END) AS failed
        FROM monitoring_logs
        WHERE monitored_at >= datetime('now', '-7 days')
        GROUP BY day
        ORDER BY day
    """).fetchall()

    return jsonify([dict(r) for r in rows])


@dashboard_bp.route('/api/chart/api-availability')
@login_required
def chart_api_availability():
    """JSON: per-API availability percentage."""
    db = get_db()
    rows = db.execute("""
        SELECT
            a.api_name,
            COUNT(ml.id)                                           AS total,
            SUM(CASE WHEN ml.availability = 1 THEN 1 ELSE 0 END)  AS ok
        FROM apis a
        LEFT JOIN monitoring_logs ml ON ml.api_id = a.id
        GROUP BY a.id, a.api_name
    """).fetchall()

    result = []
    for r in rows:
        pct = round((r['ok'] / r['total']) * 100, 1) if r['total'] else 100.0
        result.append({'api_name': r['api_name'], 'availability': pct})

    return jsonify(result)


@dashboard_bp.route('/api/recent-logs')
@login_required
def recent_logs():
    """JSON: 20 most recent monitoring log entries."""
    db = get_db()
    rows = db.execute("""
        SELECT ml.id, a.api_name, ml.response_time, ml.status_code,
               ml.availability, ml.error_message, ml.monitored_at
        FROM monitoring_logs ml
        JOIN apis a ON a.id = ml.api_id
        ORDER BY ml.monitored_at DESC
        LIMIT 20
    """).fetchall()
    return jsonify([dict(r) for r in rows])
