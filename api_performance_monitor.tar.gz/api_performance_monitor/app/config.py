"""
Application Configuration
==========================
Central configuration for the Flask application.
"""

import os
import secrets

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class Config:
    """Base configuration class."""

    # Flask Security
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)

    # Session Configuration
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = False
    PERMANENT_SESSION_LIFETIME = 3600  # 1 hour

    # Database
    DATABASE_PATH = os.path.join(BASE_DIR, 'database', 'monitor.db')

    # Monitoring Defaults
    DEFAULT_MONITOR_INTERVAL = 60    # seconds
    REQUEST_TIMEOUT = 10             # seconds per request
    MAX_RETRIES = 2

    # Alert Thresholds
    RESPONSE_TIME_THRESHOLD = 2000   # ms — above this triggers alert
    UPTIME_THRESHOLD = 95.0          # % — below this triggers alert

    # Report Settings
    REPORTS_DIR = os.path.join(BASE_DIR, 'static', 'reports')
    MAX_REPORT_ROWS = 10000

    # Grafana
    GRAFANA_URL = 'http://localhost:3000'
    GRAFANA_API_KEY = os.environ.get('GRAFANA_API_KEY', '')
