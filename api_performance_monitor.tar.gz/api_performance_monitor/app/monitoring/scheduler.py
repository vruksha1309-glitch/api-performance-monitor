"""
Monitoring Scheduler
====================
Uses Python's built-in threading (no external deps) to automatically
ping active API endpoints and store results in SQLite.
"""

import sqlite3
import time
import logging
import threading
import urllib.request
import urllib.error
from ..config import Config

logger = logging.getLogger(__name__)

_stop_event = threading.Event()
_thread: threading.Thread | None = None


def _get_conn():
    conn = sqlite3.connect(Config.DATABASE_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _ping_api(api_id: int, endpoint_url: str, api_name: str):
    start = time.time()
    try:
        req  = urllib.request.Request(endpoint_url, headers={'User-Agent': 'APM-Monitor/1.0'})
        with urllib.request.urlopen(req, timeout=Config.REQUEST_TIMEOUT) as resp:
            code = resp.status
        rt_ms = round((time.time() - start) * 1000, 2)
        ok    = 1 if code < 500 else 0
        err   = None
    except urllib.error.HTTPError as e:
        rt_ms = round((time.time() - start) * 1000, 2)
        ok    = 1 if e.code < 500 else 0   # 4xx = reachable
        code  = e.code
        err   = None
    except Exception as exc:
        rt_ms = round((time.time() - start) * 1000, 2)
        ok, code, err = 0, 0, str(exc)[:200]

    try:
        conn = _get_conn()
        conn.execute(
            """INSERT INTO monitoring_logs
               (api_id, response_time, status_code, availability, error_message)
               VALUES (?, ?, ?, ?, ?)""",
            (api_id, rt_ms, code, ok, err)
        )
        conn.commit()
        conn.close()
    except Exception as db_err:
        logger.error("DB write error api_id=%s: %s", api_id, db_err)

    logger.info("[%s] %s  %.0f ms  HTTP %s", "✓" if ok else "✗", api_name, rt_ms, code)


class _APIWorker(threading.Thread):
    """One daemon thread per active API."""
    def __init__(self, api_id, endpoint_url, api_name, interval, stop_event):
        super().__init__(daemon=True)
        self.api_id       = api_id
        self.endpoint_url = endpoint_url
        self.api_name     = api_name
        self.interval     = max(interval, 10)
        self.stop_event   = stop_event

    def run(self):
        # Initial ping immediately
        _ping_api(self.api_id, self.endpoint_url, self.api_name)
        while not self.stop_event.wait(self.interval):
            _ping_api(self.api_id, self.endpoint_url, self.api_name)


def _supervisor(app, stop_event):
    """Periodically sync worker threads with active APIs in the DB."""
    workers: dict[int, _APIWorker] = {}

    while not stop_event.is_set():
        try:
            conn  = _get_conn()
            apis  = conn.execute(
                "SELECT id, api_name, endpoint_url, monitoring_interval "
                "FROM apis WHERE status='active'"
            ).fetchall()
            conn.close()

            current_ids = {r['id'] for r in apis}

            # Remove stale workers
            for aid in list(workers.keys()):
                if aid not in current_ids:
                    workers.pop(aid)  # thread is daemon; it will die on its own

            # Start new workers
            for row in apis:
                aid = row['id']
                if aid not in workers or not workers[aid].is_alive():
                    w = _APIWorker(aid, row['endpoint_url'], row['api_name'],
                                   row['monitoring_interval'], stop_event)
                    w.start()
                    workers[aid] = w
                    logger.info("Started monitor thread for '%s'", row['api_name'])

        except Exception as exc:
            logger.error("Supervisor error: %s", exc)

        stop_event.wait(30)  # re-check every 30 s


def start_scheduler(app):
    global _thread
    logging.basicConfig(level=logging.INFO)
    _thread = threading.Thread(target=_supervisor, args=(app, _stop_event), daemon=True)
    _thread.start()
    logger.info("Monitoring scheduler started (stdlib threading).")
