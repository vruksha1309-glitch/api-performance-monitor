"""
Monitoring Blueprint
====================
CRUD for API endpoints and on-demand test pings.
"""

import requests as http_requests
import time
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from ..auth.routes import login_required
from ..database import get_db

monitoring_bp = Blueprint('monitoring', __name__)


@monitoring_bp.route('/')
@login_required
def index():
    """List all monitored APIs."""
    db = get_db()
    apis = db.execute("SELECT * FROM apis ORDER BY created_at DESC").fetchall()
    return render_template('monitoring/index.html', apis=apis)


@monitoring_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add_api():
    """Add a new API endpoint to monitor."""
    if request.method == 'POST':
        api_name  = request.form.get('api_name', '').strip()
        endpoint  = request.form.get('endpoint_url', '').strip()
        interval  = request.form.get('monitoring_interval', 60)
        status    = request.form.get('status', 'active')

        if not api_name or not endpoint:
            flash('API name and endpoint URL are required.', 'danger')
            return render_template('monitoring/add.html')

        try:
            interval = int(interval)
            if interval < 10:
                raise ValueError
        except ValueError:
            flash('Monitoring interval must be a number ≥ 10 seconds.', 'danger')
            return render_template('monitoring/add.html')

        db = get_db()
        db.execute(
            "INSERT INTO apis (api_name, endpoint_url, monitoring_interval, status) VALUES (?,?,?,?)",
            (api_name, endpoint, interval, status)
        )
        db.commit()
        flash(f'API "{api_name}" added successfully.', 'success')
        return redirect(url_for('monitoring.index'))

    return render_template('monitoring/add.html')


@monitoring_bp.route('/edit/<int:api_id>', methods=['GET', 'POST'])
@login_required
def edit_api(api_id):
    """Edit an existing API endpoint."""
    db  = get_db()
    api = db.execute("SELECT * FROM apis WHERE id = ?", (api_id,)).fetchone()

    if not api:
        flash('API not found.', 'danger')
        return redirect(url_for('monitoring.index'))

    if request.method == 'POST':
        api_name = request.form.get('api_name', '').strip()
        endpoint = request.form.get('endpoint_url', '').strip()
        interval = request.form.get('monitoring_interval', 60)
        status   = request.form.get('status', 'active')

        try:
            interval = int(interval)
        except ValueError:
            interval = 60

        db.execute(
            "UPDATE apis SET api_name=?, endpoint_url=?, monitoring_interval=?, status=? WHERE id=?",
            (api_name, endpoint, interval, status, api_id)
        )
        db.commit()
        flash(f'API "{api_name}" updated.', 'success')
        return redirect(url_for('monitoring.index'))

    return render_template('monitoring/edit.html', api=api)


@monitoring_bp.route('/delete/<int:api_id>', methods=['POST'])
@login_required
def delete_api(api_id):
    """Delete an API and all its monitoring logs."""
    db = get_db()
    api = db.execute("SELECT api_name FROM apis WHERE id = ?", (api_id,)).fetchone()
    if api:
        db.execute("DELETE FROM apis WHERE id = ?", (api_id,))
        db.commit()
        flash(f'API "{api["api_name"]}" deleted.', 'success')
    else:
        flash('API not found.', 'danger')
    return redirect(url_for('monitoring.index'))


@monitoring_bp.route('/toggle/<int:api_id>', methods=['POST'])
@login_required
def toggle_api(api_id):
    """Toggle an API's monitoring status between active and inactive."""
    db  = get_db()
    api = db.execute("SELECT status FROM apis WHERE id = ?", (api_id,)).fetchone()
    if api:
        new_status = 'inactive' if api['status'] == 'active' else 'active'
        db.execute("UPDATE apis SET status = ? WHERE id = ?", (new_status, api_id))
        db.commit()
        return jsonify({'status': new_status})
    return jsonify({'error': 'Not found'}), 404


@monitoring_bp.route('/test/<int:api_id>', methods=['POST'])
@login_required
def test_api(api_id):
    """Manually ping an API and return instant results (AJAX)."""
    db  = get_db()
    api = db.execute("SELECT * FROM apis WHERE id = ?", (api_id,)).fetchone()

    if not api:
        return jsonify({'error': 'API not found'}), 404

    start = time.time()
    try:
        resp  = http_requests.get(api['endpoint_url'], timeout=10)
        rt_ms = round((time.time() - start) * 1000, 2)
        ok    = 1
        err   = None
        code  = resp.status_code
    except Exception as exc:
        rt_ms = round((time.time() - start) * 1000, 2)
        ok    = 0
        err   = str(exc)
        code  = 0

    db.execute(
        "INSERT INTO monitoring_logs (api_id, response_time, status_code, availability, error_message) VALUES (?,?,?,?,?)",
        (api_id, rt_ms, code, ok, err)
    )
    db.commit()

    return jsonify({
        'response_time': rt_ms,
        'status_code':   code,
        'availability':  ok,
        'error_message': err,
    })


@monitoring_bp.route('/logs/<int:api_id>')
@login_required
def api_logs(api_id):
    """View last 100 monitoring logs for a specific API."""
    db  = get_db()
    api  = db.execute("SELECT * FROM apis WHERE id = ?", (api_id,)).fetchone()
    logs = db.execute("""
        SELECT * FROM monitoring_logs
        WHERE api_id = ?
        ORDER BY monitored_at DESC
        LIMIT 100
    """, (api_id,)).fetchall()
    return render_template('monitoring/logs.html', api=api, logs=logs)
