"""
Application Factory
"""

from flask import Flask
from .config import Config
from .database import init_db


def create_app(config_class=Config):
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    app.config.from_object(config_class)

    with app.app_context():
        init_db()

    from .auth.routes import auth_bp
    from .dashboard.routes import dashboard_bp
    from .monitoring.routes import monitoring_bp
    from .reports.routes import reports_bp
    from .alerts.routes import alerts_bp

    app.register_blueprint(auth_bp,        url_prefix='/auth')
    app.register_blueprint(dashboard_bp,   url_prefix='/')
    app.register_blueprint(monitoring_bp,  url_prefix='/monitoring')
    app.register_blueprint(reports_bp,     url_prefix='/reports')
    app.register_blueprint(alerts_bp,      url_prefix='/alerts')

    return app
