"""
Alerts Blueprint
================
Detect and display API downtime and performance alerts.
"""

from flask import Blueprint, render_template, jsonify
from ..auth.routes import login_required
from ..database import get_db
from ..config import Config

alerts_bp = Blueprint('alerts', __name__)


@alerts_bp.route('/')
@login_required
def index():
    """Alerts dashboard page."""
    return render_template('alerts/index.html')


@alerts_bp.route('/api/active')
@login_required
def active_alerts():
    """
    JSON: detect current alerts.
    - Down APIs  : last log shows availability=0
    - Slow APIs  : last avg response_time > threshold
    - Low uptime : overall uptime % below threshold
    """
    db = get_db()
    alerts = []

    # ── Down / Slow detection per API ─────────────────────────────────────────
    apis = db.execute("SELECT * FROM apis WHERE status = 'active'").fetchall()

    for api in apis:
        last_log = db.execute("""
            SELECT * FROM monitoring_logs
            WHERE api_id = ?
            ORDER BY monitored_at DESC LIMIT 1
        """, (api['id'],)).fetchone()

        if not last_log:
            continue

        # API is down
        if last_log['availability'] == 0:
            alerts.append({
                'type':     'danger',
                'api_name': api['api_name'],
                'message':  "API is DOWN — " + (last_log['error_message'] or f"HTTP {last_log['status_code']}"),
                'time':     last_log['monitored_at'],
            })

        # Slow response
        elif last_log['response_time'] and last_log['response_time'] > Config.RESPONSE_TIME_THRESHOLD:
            alerts.append({
                'type':     'warning',
                'api_name': api['api_name'],
                'message':  f"Slow response — {last_log['response_time']:.0f} ms (threshold: {Config.RESPONSE_TIME_THRESHOLD} ms)",
                'time':     last_log['monitored_at'],
            })

    # ── Low uptime ─────────────────────────────────────────────────────────────
    uptime_rows = db.execute("""
        SELECT a.api_name,
               COUNT(ml.id)  AS total,
               SUM(CASE WHEN ml.availability = 1 THEN 1 ELSE 0 END) AS ok
        FROM apis a
        JOIN monitoring_logs ml ON ml.api_id = a.id
        WHERE ml.monitored_at >= datetime('now', '-24 hours')
        GROUP BY a.id
    """).fetchall()

    for row in uptime_rows:
        if row['total'] == 0:
            continue
        uptime = (row['ok'] / row['total']) * 100
        if uptime < Config.UPTIME_THRESHOLD:
            alerts.append({
                'type':     'warning',
                'api_name': row['api_name'],
                'message':  f"Low 24 h uptime — {uptime:.1f}% (threshold: {Config.UPTIME_THRESHOLD}%)",
                'time':     None,
            })

    return jsonify(alerts)


@alerts_bp.route('/api/history')
@login_required
def alert_history():
    """JSON: last 50 failure log entries across all APIs."""
    db = get_db()
    rows = db.execute("""
        SELECT ml.monitored_at, a.api_name, ml.status_code,
               ml.response_time, ml.error_message
        FROM monitoring_logs ml
        JOIN apis a ON a.id = ml.api_id
        WHERE ml.availability = 0
        ORDER BY ml.monitored_at DESC
        LIMIT 50
    """).fetchall()
    return jsonify([dict(r) for r in rows])
