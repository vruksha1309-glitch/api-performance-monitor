"""
Authentication Blueprint
========================
Handles admin login, logout, and session management.
"""

import hashlib
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from ..database import get_db

auth_bp = Blueprint('auth', __name__)


def hash_password(password: str) -> str:
    """Return SHA-256 hash of a password string."""
    return hashlib.sha256(password.encode()).hexdigest()


def login_required(f):
    """Decorator: redirect to login if user is not authenticated."""
    from functools import wraps

    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)

    return decorated


# ── Routes ────────────────────────────────────────────────────────────────────

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Admin login page."""
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Username and password are required.', 'danger')
            return render_template('auth/login.html')

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()

        if user and user['password'] == hash_password(password):
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('dashboard.index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('auth/login.html')


@auth_bp.route('/logout')
def logout():
    """Clear session and redirect to login."""
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    """Allow admin to change their password."""
    if request.method == 'POST':
        current = request.form.get('current_password', '')
        new_pw  = request.form.get('new_password', '')
        confirm = request.form.get('confirm_password', '')

        if new_pw != confirm:
            flash('New passwords do not match.', 'danger')
            return render_template('auth/change_password.html')

        if len(new_pw) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return render_template('auth/change_password.html')

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE id = ?", (session['user_id'],)
        ).fetchone()

        if user['password'] != hash_password(current):
            flash('Current password is incorrect.', 'danger')
            return render_template('auth/change_password.html')

        db.execute(
            "UPDATE users SET password = ? WHERE id = ?",
            (hash_password(new_pw), session['user_id'])
        )
        db.commit()
        flash('Password updated successfully.', 'success')
        return redirect(url_for('dashboard.index'))

    return render_template('auth/change_password.html')
