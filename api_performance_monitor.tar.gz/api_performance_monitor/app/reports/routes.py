"""
Reports Blueprint
=================
Generate and download PDF and CSV performance reports.
"""

import csv
import io
import os
from datetime import datetime, date

from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, send_file, jsonify, current_app)
from ..auth.routes import login_required
from ..database import get_db

reports_bp = Blueprint('reports', __name__)


def _fetch_logs(db, start_date, end_date, api_id=None):
    """Return monitoring logs filtered by date range and optional API."""
    base_q = """
        SELECT ml.id, a.api_name, ml.response_time, ml.status_code,
               ml.availability, ml.error_message, ml.monitored_at
        FROM monitoring_logs ml
        JOIN apis a ON a.id = ml.api_id
        WHERE ml.monitored_at BETWEEN ? AND ?
    """
    params = [start_date + ' 00:00:00', end_date + ' 23:59:59']

    if api_id:
        base_q += " AND ml.api_id = ?"
        params.append(api_id)

    base_q += " ORDER BY ml.monitored_at DESC"
    return db.execute(base_q, params).fetchall()


@reports_bp.route('/')
@login_required
def index():
    """Reports home page."""
    db        = get_db()
    apis      = db.execute("SELECT id, api_name FROM apis ORDER BY api_name").fetchall()
    past_rpts = db.execute(
        "SELECT * FROM reports ORDER BY generated_at DESC LIMIT 20"
    ).fetchall()
    return render_template('reports/index.html', apis=apis, past_reports=past_rpts)


@reports_bp.route('/export/csv', methods=['POST'])
@login_required
def export_csv():
    """Generate and stream a CSV report."""
    start_date = request.form.get('start_date', str(date.today()))
    end_date   = request.form.get('end_date',   str(date.today()))
    api_id     = request.form.get('api_id') or None

    db   = get_db()
    rows = _fetch_logs(db, start_date, end_date, api_id)

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'API Name', 'Response Time (ms)',
                     'Status Code', 'Available', 'Error', 'Monitored At'])

    for row in rows:
        writer.writerow([
            row['id'], row['api_name'],
            row['response_time'], row['status_code'],
            'Yes' if row['availability'] else 'No',
            row['error_message'] or '',
            row['monitored_at'],
        ])

    # Save report record
    report_name = f"CSV_Report_{start_date}_to_{end_date}"
    db.execute(
        "INSERT INTO reports (report_name, report_type) VALUES (?,?)",
        (report_name, 'csv')
    )
    db.commit()

    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name=f"api_report_{start_date}_{end_date}.csv"
    )


@reports_bp.route('/export/pdf', methods=['POST'])
@login_required
def export_pdf():
    """Generate a minimal HTML→PDF-style report and stream it."""
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    start_date = request.form.get('start_date', str(date.today()))
    end_date   = request.form.get('end_date',   str(date.today()))
    api_id     = request.form.get('api_id') or None

    db   = get_db()
    rows = _fetch_logs(db, start_date, end_date, api_id)

    # ── ReportLab PDF ─────────────────────────────────────────────────────────
    buf    = io.BytesIO()
    doc    = SimpleDocTemplate(buf, pagesize=landscape(A4), rightMargin=20, leftMargin=20,
                                topMargin=30, bottomMargin=20)
    styles = getSampleStyleSheet()
    story  = []

    story.append(Paragraph("API Performance Monitor — Performance Report", styles['Title']))
    story.append(Paragraph(f"Period: {start_date} to {end_date}", styles['Normal']))
    story.append(Spacer(1, 12))

    # Summary stats
    total   = len(rows)
    success = sum(1 for r in rows if r['availability'])
    failed  = total - success
    avg_rt  = (sum(r['response_time'] for r in rows if r['response_time']) / total
               if total else 0)

    summary = [
        ['Total Requests', str(total)],
        ['Successful',     str(success)],
        ['Failed',         str(failed)],
        ['Avg Response Time', f"{avg_rt:.1f} ms"],
        ['Uptime %',       f"{(success/total*100):.1f}%" if total else 'N/A'],
    ]
    st = Table(summary, colWidths=[160, 100])
    st.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#1a1a2e')),
        ('TEXTCOLOR',  (0,0), (0,-1), colors.white),
        ('FONTNAME',   (0,0), (-1,-1), 'Helvetica'),
        ('GRID',       (0,0), (-1,-1), 0.5, colors.grey),
        ('ROWBACKGROUNDS', (0,0), (-1,-1), [colors.whitesmoke, colors.white]),
    ]))
    story.append(st)
    story.append(Spacer(1, 16))

    # Detail table (limited to first 500 rows to keep PDF manageable)
    headers = ['API Name', 'Response Time (ms)', 'Status Code', 'Available', 'Monitored At']
    data    = [headers] + [
        [r['api_name'], f"{r['response_time']:.1f}" if r['response_time'] else 'N/A',
         str(r['status_code']), 'Yes' if r['availability'] else 'No', r['monitored_at']]
        for r in rows[:500]
    ]

    tbl = Table(data, repeatRows=1)
    tbl.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e94560')),
        ('TEXTCOLOR',  (0,0), (-1,0), colors.white),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE',   (0,0), (-1,-1), 7),
        ('GRID',       (0,0), (-1,-1), 0.25, colors.lightgrey),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f8f8f8')]),
    ]))
    story.append(tbl)

    doc.build(story)
    buf.seek(0)

    # Save report record
    db.execute(
        "INSERT INTO reports (report_name, report_type) VALUES (?,?)",
        (f"PDF_Report_{start_date}_to_{end_date}", 'pdf')
    )
    db.commit()

    return send_file(
        buf, mimetype='application/pdf', as_attachment=True,
        download_name=f"api_report_{start_date}_{end_date}.pdf"
    )


@reports_bp.route('/api/summary')
@login_required
def api_summary():
    """JSON: per-API summary statistics."""
    db = get_db()
    rows = db.execute("""
        SELECT
            a.api_name,
            COUNT(ml.id)                                           AS total,
            SUM(CASE WHEN ml.availability = 1 THEN 1 ELSE 0 END)  AS ok,
            ROUND(AVG(ml.response_time), 2)                        AS avg_rt,
            MAX(ml.response_time)                                  AS max_rt,
            MIN(ml.response_time)                                  AS min_rt
        FROM apis a
        LEFT JOIN monitoring_logs ml ON ml.api_id = a.id
        GROUP BY a.id, a.api_name
        ORDER BY a.api_name
    """).fetchall()

    result = []
    for r in rows:
        uptime = round((r['ok'] / r['total']) * 100, 1) if r['total'] else 100.0
        result.append({**dict(r), 'uptime': uptime})

    return jsonify(result)
