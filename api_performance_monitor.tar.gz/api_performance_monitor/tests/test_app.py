"""
Test Suite — API Performance Monitor
=====================================
Run: python -m pytest tests/ -v
"""

import sys, os, hashlib, sqlite3, time
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from app import create_app
from app.database import init_db


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture(scope='session')
def app():
    """Create app with a temporary in-memory-style DB."""
    import tempfile, shutil
    tmp = tempfile.mkdtemp()
    test_db = os.path.join(tmp, 'test_monitor.db')

    os.environ['DATABASE_PATH_OVERRIDE'] = test_db

    from app.config import Config
    Config.DATABASE_PATH = test_db
    Config.TESTING = True

    application = create_app(Config)
    application.config['TESTING'] = True
    application.config['WTF_CSRF_ENABLED'] = False

    with application.app_context():
        init_db()

    yield application
    shutil.rmtree(tmp, ignore_errors=True)


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def auth_client(client):
    """Return a client that is already logged in as admin."""
    client.post('/auth/login', data={'username': 'admin', 'password': 'admin123'})
    return client


# ── Authentication Tests ─────────────────────────────────────────────────────

class TestAuth:
    def test_login_page_loads(self, client):
        r = client.get('/auth/login')
        assert r.status_code == 200
        assert b'Sign In' in r.data

    def test_login_success(self, client):
        r = client.post('/auth/login',
                        data={'username': 'admin', 'password': 'admin123'},
                        follow_redirects=True)
        assert r.status_code == 200
        assert b'Dashboard' in r.data or b'Total APIs' in r.data

    def test_login_wrong_password(self, client):
        r = client.post('/auth/login',
                        data={'username': 'admin', 'password': 'wrong'},
                        follow_redirects=True)
        assert b'Invalid' in r.data

    def test_login_empty_fields(self, client):
        r = client.post('/auth/login', data={'username': '', 'password': ''},
                        follow_redirects=True)
        assert b'required' in r.data

    def test_protected_redirect(self, client):
        r = client.get('/', follow_redirects=False)
        assert r.status_code == 302

    def test_logout(self, auth_client):
        r = auth_client.get('/auth/logout', follow_redirects=True)
        assert b'logged out' in r.data or r.status_code == 200


# ── Dashboard Tests ──────────────────────────────────────────────────────────

class TestDashboard:
    def test_dashboard_loads(self, auth_client):
        r = auth_client.get('/')
        assert r.status_code == 200

    def test_stats_api(self, auth_client):
        r = auth_client.get('/api/stats')
        assert r.status_code == 200
        d = r.get_json()
        assert 'total_apis' in d
        assert 'uptime_percentage' in d

    def test_daily_chart_api(self, auth_client):
        r = auth_client.get('/api/chart/daily-stats')
        assert r.status_code == 200
        assert isinstance(r.get_json(), list)

    def test_availability_chart_api(self, auth_client):
        r = auth_client.get('/api/chart/api-availability')
        assert r.status_code == 200

    def test_recent_logs_api(self, auth_client):
        r = auth_client.get('/api/recent-logs')
        assert r.status_code == 200
        assert isinstance(r.get_json(), list)


# ── Monitoring Tests ─────────────────────────────────────────────────────────

class TestMonitoring:
    def test_monitoring_page_loads(self, auth_client):
        r = auth_client.get('/monitoring/')
        assert r.status_code == 200

    def test_add_api(self, auth_client):
        r = auth_client.post('/monitoring/add', data={
            'api_name': 'Test API',
            'endpoint_url': 'https://httpbin.org/get',
            'monitoring_interval': '60',
            'status': 'active',
        }, follow_redirects=True)
        assert r.status_code == 200
        assert b'Test API' in r.data

    def test_add_api_missing_fields(self, auth_client):
        r = auth_client.post('/monitoring/add', data={
            'api_name': '',
            'endpoint_url': '',
        }, follow_redirects=True)
        assert b'required' in r.data

    def test_edit_api(self, auth_client, app):
        # Ensure at least one API exists
        with app.app_context():
            from app.database import get_db
            with app.test_request_context():
                db = sqlite3.connect(app.config['DATABASE_PATH'])
                row = db.execute("SELECT id FROM apis LIMIT 1").fetchone()
                db.close()
                if row:
                    r = auth_client.post(f'/monitoring/edit/{row[0]}', data={
                        'api_name': 'Edited Name',
                        'endpoint_url': 'https://httpbin.org/get',
                        'monitoring_interval': '45',
                        'status': 'active',
                    }, follow_redirects=True)
                    assert r.status_code == 200

    def test_toggle_api(self, auth_client, app):
        db = sqlite3.connect(app.config['DATABASE_PATH'])
        row = db.execute("SELECT id FROM apis LIMIT 1").fetchone()
        db.close()
        if row:
            r = auth_client.post(f'/monitoring/toggle/{row[0]}')
            assert r.status_code == 200
            assert 'status' in r.get_json()

    def test_delete_api(self, auth_client):
        # Add one and delete it
        auth_client.post('/monitoring/add', data={
            'api_name': 'Delete Me',
            'endpoint_url': 'https://example.com',
            'monitoring_interval': '60',
            'status': 'active',
        })
        db_path = auth_client.application.config['DATABASE_PATH']
        conn = sqlite3.connect(db_path)
        row = conn.execute("SELECT id FROM apis WHERE api_name='Delete Me'").fetchone()
        conn.close()
        if row:
            r = auth_client.post(f'/monitoring/delete/{row[0]}', follow_redirects=True)
            assert r.status_code == 200


# ── Alerts Tests ─────────────────────────────────────────────────────────────

class TestAlerts:
    def test_alerts_page(self, auth_client):
        r = auth_client.get('/alerts/')
        assert r.status_code == 200

    def test_active_alerts_api(self, auth_client):
        r = auth_client.get('/alerts/api/active')
        assert r.status_code == 200
        assert isinstance(r.get_json(), list)

    def test_history_api(self, auth_client):
        r = auth_client.get('/alerts/api/history')
        assert r.status_code == 200


# ── Reports Tests ─────────────────────────────────────────────────────────────

class TestReports:
    def test_reports_page(self, auth_client):
        r = auth_client.get('/reports/')
        assert r.status_code == 200

    def test_summary_api(self, auth_client):
        r = auth_client.get('/reports/api/summary')
        assert r.status_code == 200
        assert isinstance(r.get_json(), list)

    def test_csv_export(self, auth_client):
        r = auth_client.post('/reports/export/csv', data={
            'start_date': '2024-01-01',
            'end_date': '2099-12-31',
            'api_id': '',
        })
        assert r.status_code == 200
        assert b'API Name' in r.data


# ── Database Tests ────────────────────────────────────────────────────────────

class TestDatabase:
    def test_schema_exists(self, app):
        conn = sqlite3.connect(app.config['DATABASE_PATH'])
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        conn.close()
        assert 'users'           in tables
        assert 'apis'            in tables
        assert 'monitoring_logs' in tables
        assert 'reports'         in tables

    def test_admin_seeded(self, app):
        conn = sqlite3.connect(app.config['DATABASE_PATH'])
        row  = conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
        conn.close()
        assert row is not None

    def test_password_hash(self):
        pw   = 'admin123'
        h    = hashlib.sha256(pw.encode()).hexdigest()
        assert len(h) == 64


# ── Utility Tests ─────────────────────────────────────────────────────────────

class TestUtils:
    def test_response_time_measured(self):
        """Ensure a simple timing measurement works."""
        start = time.time()
        time.sleep(0.05)
        elapsed = (time.time() - start) * 1000
        assert elapsed >= 45  # at least ~50 ms

    def test_availability_logic(self):
        def is_available(code): return 1 if code and code < 500 else 0
        assert is_available(200) == 1
        assert is_available(404) == 1   # reachable, just not found
        assert is_available(500) == 0
        assert is_available(0)   == 0
        assert is_available(None)== 0
