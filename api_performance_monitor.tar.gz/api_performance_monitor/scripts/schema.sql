-- ============================================================
-- API Performance Monitor — SQL Schema
-- Run: sqlite3 database/monitor.db < scripts/schema.sql
-- ============================================================

PRAGMA foreign_keys = ON;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT    NOT NULL UNIQUE,
    password    TEXT    NOT NULL,             -- SHA-256 hex
    role        TEXT    NOT NULL DEFAULT 'admin',
    created_at  TEXT    DEFAULT (datetime('now'))
);

-- APIs to monitor
CREATE TABLE IF NOT EXISTS apis (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    api_name            TEXT    NOT NULL,
    endpoint_url        TEXT    NOT NULL,
    monitoring_interval INTEGER NOT NULL DEFAULT 60,  -- seconds
    status              TEXT    NOT NULL DEFAULT 'active',  -- active | inactive
    created_at          TEXT    DEFAULT (datetime('now'))
);

-- Monitoring results
CREATE TABLE IF NOT EXISTS monitoring_logs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    api_id        INTEGER NOT NULL REFERENCES apis(id) ON DELETE CASCADE,
    response_time REAL,          -- milliseconds
    status_code   INTEGER,       -- HTTP status
    availability  INTEGER NOT NULL DEFAULT 1,  -- 1=up, 0=down
    error_message TEXT,
    monitored_at  TEXT DEFAULT (datetime('now'))
);

-- Generated reports index
CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    report_name  TEXT NOT NULL,
    report_type  TEXT NOT NULL DEFAULT 'pdf',  -- pdf | csv
    file_path    TEXT,
    generated_at TEXT DEFAULT (datetime('now'))
);

-- Performance indexes
CREATE INDEX IF NOT EXISTS idx_logs_api      ON monitoring_logs(api_id);
CREATE INDEX IF NOT EXISTS idx_logs_time     ON monitoring_logs(monitored_at);
CREATE INDEX IF NOT EXISTS idx_logs_avail    ON monitoring_logs(availability);

-- Default admin (password: admin123)
INSERT OR IGNORE INTO users (username, password, role)
VALUES ('admin',
        '240be518fabd2724ddb6f04eeb1da5967448d7e831d3d36d98445f8a5f7ba4c',
        'admin');

-- Sample APIs
INSERT OR IGNORE INTO apis (api_name, endpoint_url, monitoring_interval, status) VALUES
  ('JSONPlaceholder Posts', 'https://jsonplaceholder.typicode.com/posts', 30,  'active'),
  ('JSONPlaceholder Users', 'https://jsonplaceholder.typicode.com/users', 60,  'active'),
  ('HTTPBin GET',           'https://httpbin.org/get',                    45,  'active'),
  ('GitHub API',            'https://api.github.com',                     60,  'active');
