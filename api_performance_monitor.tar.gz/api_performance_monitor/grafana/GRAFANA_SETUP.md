# Grafana Integration Guide
# API Performance Monitor

## 1. Install Grafana

### Ubuntu / Debian
```bash
sudo apt-get install -y adduser libfontconfig1 musl
wget https://dl.grafana.com/oss/release/grafana_10.4.2_amd64.deb
sudo dpkg -i grafana_10.4.2_amd64.deb
sudo systemctl start grafana-server
sudo systemctl enable grafana-server
```

### macOS (Homebrew)
```bash
brew install grafana
brew services start grafana
```

## 2. Install the SQLite Plugin

```bash
grafana-cli plugins install frser-sqlite-datasource
sudo systemctl restart grafana-server
```

## 3. Open Grafana
Navigate to: http://localhost:3000
Default credentials: admin / admin

## 4. Add SQLite Data Source
1. Go to Configuration → Data Sources → Add data source
2. Search for "SQLite"
3. Set path: /absolute/path/to/api_performance_monitor/database/monitor.db
4. Click "Save & Test"

## 5. Import Dashboard JSON

Go to Dashboards → Import → Upload JSON File
Use the panels below as a starting point.

---

## Panel Queries

### Panel 1 — Average Response Time per API (Time Series)
```sql
SELECT
  datetime(monitored_at) as time,
  api_id,
  AVG(response_time) as avg_response_time
FROM monitoring_logs
WHERE $__timeFilter(monitored_at)
GROUP BY api_id, strftime('%Y-%m-%dT%H:%M:00', monitored_at)
ORDER BY time
```

### Panel 2 — Error Rate % (Gauge)
```sql
SELECT
  ROUND(
    (SUM(CASE WHEN availability = 0 THEN 1.0 ELSE 0 END) / COUNT(*)) * 100, 2
  ) as error_rate_pct
FROM monitoring_logs
WHERE monitored_at >= datetime('now', '-24 hours')
```

### Panel 3 — Uptime % per API (Bar Chart)
```sql
SELECT
  a.api_name,
  ROUND(
    (SUM(CASE WHEN ml.availability = 1 THEN 1.0 ELSE 0 END) / COUNT(*)) * 100, 2
  ) as uptime_pct
FROM monitoring_logs ml
JOIN apis a ON a.id = ml.api_id
WHERE ml.monitored_at >= datetime('now', '-24 hours')
GROUP BY a.id
ORDER BY uptime_pct DESC
```

### Panel 4 — Request Volume (Time Series)
```sql
SELECT
  datetime(strftime('%Y-%m-%dT%H:00:00', monitored_at)) as time,
  COUNT(*) as requests
FROM monitoring_logs
WHERE $__timeFilter(monitored_at)
GROUP BY strftime('%Y-%m-%dT%H', monitored_at)
ORDER BY time
```

### Panel 5 — API Status Table (Table)
```sql
SELECT
  a.api_name,
  a.status,
  COUNT(ml.id)  as total_checks,
  ROUND(AVG(ml.response_time), 1) as avg_rt_ms,
  SUM(CASE WHEN ml.availability = 0 THEN 1 ELSE 0 END) as failures
FROM apis a
LEFT JOIN monitoring_logs ml ON ml.api_id = a.id
GROUP BY a.id
ORDER BY failures DESC
```

---

## 6. Alerting (Optional)

In Grafana Alerting → Alert Rules:
- Trigger when `avg_response_time > 2000` for 2 consecutive evaluations
- Trigger when `uptime_pct < 95` for any API
- Configure notification channel (email, Slack, PagerDuty) under Contact Points

---

## Recommended Dashboard Layout

```
┌─────────────────────────────────────────────────────────────┐
│  Row 1: Stat Panels — Total APIs | Uptime | Avg RT | Errors │
├───────────────────────────┬─────────────────────────────────┤
│  Response Time (Line)     │   Request Volume (Bar)          │
├───────────────────────────┼─────────────────────────────────┤
│  Uptime % per API (Bar)   │   Error Rate (Gauge)            │
├─────────────────────────────────────────────────────────────┤
│  API Status Table (full width)                              │
└─────────────────────────────────────────────────────────────┘
```
