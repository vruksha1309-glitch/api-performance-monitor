/* main.js — shared utilities */

// ── Live clock ─────────────────────────────────────────────────────────────
const clockEl = document.getElementById('clock');
if (clockEl) {
  const tick = () => { clockEl.textContent = new Date().toLocaleTimeString(); };
  tick(); setInterval(tick, 1000);
}

// ── Alert badge (nav) ───────────────────────────────────────────────────────
async function refreshAlertBadge() {
  try {
    const r = await fetch('/alerts/api/active');
    const alerts = await r.json();
    const badge = document.getElementById('alertBadge');
    if (badge) {
      if (alerts.length > 0) {
        badge.textContent = alerts.length;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    }
  } catch (_) {}
}
refreshAlertBadge();
setInterval(refreshAlertBadge, 30000);

// ── Utility: show a toast message ─────────────────────────────────────────
window.showToast = function(html, ms = 3500) {
  const t = document.getElementById('testToast') || (() => {
    const el = document.createElement('div');
    el.className = 'toast';
    el.id = 'testToast';
    document.body.appendChild(el);
    return el;
  })();
  t.innerHTML = html;
  t.style.display = 'block';
  clearTimeout(t._tid);
  t._tid = setTimeout(() => { t.style.display = 'none'; }, ms);
};
