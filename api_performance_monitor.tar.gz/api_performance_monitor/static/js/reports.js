/* reports.js */

// Default dates to today / last 7 days
const today = new Date().toISOString().split('T')[0];
const week  = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0];

document.getElementById('startDate').value = week;
document.getElementById('endDate').value   = today;

// Fill hidden form fields before submit
['csv', 'pdf'].forEach(type => {
  document.getElementById(`${type}Form`).addEventListener('submit', () => {
    document.getElementById(`${type}Start`).value = document.getElementById('startDate').value;
    document.getElementById(`${type}End`).value   = document.getElementById('endDate').value;
    document.getElementById(`${type}Api`).value   = document.getElementById('apiFilter').value;
  });
});

// Load summary table
async function loadSummary() {
  const r    = await fetch('/reports/api/summary');
  const data = await r.json();
  const tbody = document.getElementById('summaryBody');

  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">No data.</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(d => `
    <tr>
      <td><strong>${escHtml(d.api_name)}</strong></td>
      <td>${d.total || 0}</td>
      <td>
        <span class="badge badge-${d.uptime >= 95 ? 'green' : d.uptime >= 80 ? 'orange' : 'red'}">
          ${d.uptime}%
        </span>
      </td>
      <td>${d.avg_rt != null ? d.avg_rt + ' ms' : '—'}</td>
      <td>${d.max_rt != null ? d.max_rt.toFixed(1) + ' ms' : '—'}</td>
    </tr>
  `).join('');
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

loadSummary();
