/* monitoring.js — toggle and test buttons */

document.querySelectorAll('.toggle-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    try {
      const r = await fetch(`/monitoring/toggle/${id}`, { method: 'POST' });
      const d = await r.json();
      if (d.status) location.reload();
    } catch (e) { showToast('Toggle failed: ' + e.message); }
  });
});

document.querySelectorAll('.test-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const id = btn.dataset.id;
    const orig = btn.innerHTML;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
    btn.disabled  = true;

    try {
      const r = await fetch(`/monitoring/test/${id}`, { method: 'POST' });
      const d = await r.json();
      const ok = d.availability === 1;
      showToast(
        `<strong>${ok ? '✓ OK' : '✗ FAIL'}</strong> &nbsp;
         HTTP ${d.status_code || '—'} &nbsp;|&nbsp;
         ${d.response_time != null ? d.response_time.toFixed(1) : '—'} ms
         ${d.error_message ? '<br><small style="color:var(--red)">' + d.error_message + '</small>' : ''}`,
        4000
      );
    } catch (e) { showToast('Test error: ' + e.message); }

    btn.innerHTML = orig;
    btn.disabled  = false;
  });
});
