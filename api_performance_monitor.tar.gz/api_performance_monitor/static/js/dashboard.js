/* dashboard.js — loads stats and renders Chart.js charts */

const CHART_DEFAULTS = {
  color: '#e6edf3',
  gridColor: 'rgba(48,54,61,.6)',
  font: { family: "'Courier New', monospace", size: 11 },
};

// ── Helpers ────────────────────────────────────────────────────────────────
function applyDefaults(chart) {
  Chart.defaults.color = CHART_DEFAULTS.color;
  Chart.defaults.font  = CHART_DEFAULTS.font;
}

const PALETTE = [
  '#e94560','#58a6ff','#3fb950','#bc8cff',
  '#f0883e','#39c5cf','#d29922','#f85149',
];

// ── Stat cards ─────────────────────────────────────────────────────────────
async function loadStats() {
  try {
    const r    = await fetch('/api/stats');
    const data = await r.json();
    document.getElementById('totalApis').textContent    = data.total_apis;
    document.getElementById('activeApis').textContent   = data.active_apis;
    document.getElementById('avgRT').textContent        = data.avg_response_time.toFixed(1);
    document.getElementById('totalReqs').textContent    = data.total_requests.toLocaleString();
    document.getElementById('failedReqs').textContent   = data.failed_requests.toLocaleString();
    document.getElementById('uptime').textContent       = data.uptime_percentage.toFixed(1) + '%';
  } catch (e) { console.error('Stats error', e); }
}

// ── Response time chart (line) ─────────────────────────────────────────────
let rtChart;
async function loadRTChart() {
  try {
    const r    = await fetch('/api/chart/response-time');
    const data = await r.json();

    const labels = new Set();
    Object.values(data).forEach(pts => pts.forEach(p => labels.add(p.hour)));
    const sortedLabels = [...labels].sort();

    const datasets = Object.entries(data).map(([name, pts], i) => {
      const map = Object.fromEntries(pts.map(p => [p.hour, p.avg_rt]));
      return {
        label: name,
        data: sortedLabels.map(h => map[h] ?? null),
        borderColor: PALETTE[i % PALETTE.length],
        backgroundColor: 'transparent',
        tension: 0.3,
        pointRadius: 3,
        spanGaps: true,
      };
    });

    const ctx = document.getElementById('rtChart').getContext('2d');
    if (rtChart) rtChart.destroy();
    rtChart = new Chart(ctx, {
      type: 'line',
      data: { labels: sortedLabels, datasets },
      options: {
        responsive: true, maintainAspectRatio: true,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: CHART_DEFAULTS.font } } },
        scales: {
          x: { grid: { color: CHART_DEFAULTS.gridColor }, ticks: { maxTicksLimit: 12 } },
          y: { grid: { color: CHART_DEFAULTS.gridColor }, title: { display: true, text: 'ms' } },
        },
      },
    });
  } catch (e) { console.error('RT chart error', e); }
}

// ── Daily stats chart (bar) ────────────────────────────────────────────────
let dailyChart;
async function loadDailyChart() {
  try {
    const r    = await fetch('/api/chart/daily-stats');
    const data = await r.json();

    const labels  = data.map(d => d.day);
    const totals  = data.map(d => d.total);
    const failed  = data.map(d => d.failed);

    const ctx = document.getElementById('dailyChart').getContext('2d');
    if (dailyChart) dailyChart.destroy();
    dailyChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Total',  data: totals, backgroundColor: 'rgba(88,166,255,.6)',  borderRadius: 4 },
          { label: 'Failed', data: failed, backgroundColor: 'rgba(248,81,73,.6)',   borderRadius: 4 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: true,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } },
        scales: {
          x: { grid: { color: CHART_DEFAULTS.gridColor } },
          y: { grid: { color: CHART_DEFAULTS.gridColor }, beginAtZero: true },
        },
      },
    });
  } catch (e) { console.error('Daily chart error', e); }
}

// ── Availability doughnut ──────────────────────────────────────────────────
let availChart;
async function loadAvailChart() {
  try {
    const r    = await fetch('/api/chart/api-availability');
    const data = await r.json();

    const ctx = document.getElementById('availChart').getContext('2d');
    if (availChart) availChart.destroy();
    availChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: data.map(d => d.api_name),
        datasets: [{
          data: data.map(d => d.availability),
          backgroundColor: PALETTE,
          borderColor: '#161b22',
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: true,
        plugins: {
          legend: { position: 'right', labels: { boxWidth: 10, font: { size: 11 } } },
          tooltip: { callbacks: { label: c => ` ${c.label}: ${c.raw}%` } },
        },
      },
    });
  } catch (e) { console.error('Avail chart error', e); }
}

// ── Recent logs table ──────────────────────────────────────────────────────
async function loadRecentLogs() {
  try {
    const r    = await fetch('/api/recent-logs');
    const logs = await r.json();
    const tbody = document.getElementById('recentBody');
    if (!tbody) return;

    if (!logs.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center">No logs yet — monitoring will populate this.</td></tr>';
      return;
    }

    tbody.innerHTML = logs.map(l => `
      <tr class="${l.availability ? '' : 'row-fail'}">
        <td><strong>${escHtml(l.api_name)}</strong></td>
        <td><span class="badge badge-${l.status_code && l.status_code < 400 ? 'green' : 'red'}">${l.status_code || '—'}</span></td>
        <td>${l.response_time != null ? l.response_time.toFixed(1) : '—'}</td>
        <td>${l.availability
              ? '<i class="fa-solid fa-circle-check" style="color:var(--green)"></i>'
              : '<i class="fa-solid fa-circle-xmark" style="color:var(--red)"></i>'}</td>
        <td style="font-family:monospace;font-size:11px">${l.monitored_at}</td>
      </tr>
    `).join('');
  } catch (e) { console.error('Recent logs error', e); }
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ── Boot ───────────────────────────────────────────────────────────────────
applyDefaults();
loadStats();
loadRTChart();
loadDailyChart();
loadAvailChart();
loadRecentLogs();

// Refresh every 30 s
setInterval(() => { loadStats(); loadRecentLogs(); }, 30000);
setInterval(() => { loadRTChart(); loadDailyChart(); loadAvailChart(); }, 60000);
