/* alerts.js */

const ICONS = { danger: 'circle-xmark', warning: 'triangle-exclamation' };

async function loadActive() {
  const r    = await fetch('/alerts/api/active');
  const data = await r.json();
  const el   = document.getElementById('activeAlerts');

  if (!data.length) {
    el.innerHTML = '<p style="color:var(--green);text-align:center"><i class="fa-solid fa-circle-check"></i> All APIs are healthy.</p>';
    return;
  }

  el.innerHTML = data.map(a => `
    <div class="alert-card ${a.type}">
      <i class="fa-solid fa-${ICONS[a.type] || 'bell'}" style="font-size:18px;margin-top:2px"></i>
      <div>
        <div class="ac-title">${escHtml(a.api_name)}</div>
        <div class="ac-msg">${escHtml(a.message)}</div>
        ${a.time ? `<div class="ac-time">${a.time}</div>` : ''}
      </div>
    </div>
  `).join('');
}

async function loadHistory() {
  const r    = await fetch('/alerts/api/history');
  const data = await r.json();
  const tbody = document.getElementById('historyBody');

  if (!data.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">No failures recorded.</td></tr>';
    return;
  }

  tbody.innerHTML = data.map(r => `
    <tr>
      <td style="font-family:monospace;font-size:11px">${r.monitored_at}</td>
      <td><strong>${escHtml(r.api_name)}</strong></td>
      <td><span class="badge badge-red">${r.status_code || '—'}</span></td>
      <td>${r.response_time != null ? r.response_time.toFixed(1) : '—'}</td>
      <td class="err-cell">${escHtml(r.error_message || '')}</td>
    </tr>
  `).join('');
}

function escHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

loadActive();
loadHistory();
setInterval(loadActive, 30000);
